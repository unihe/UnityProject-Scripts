﻿using RobustFSM.Base;

namespace Assets.SuperGoalie.Scripts.States.GoalKeeperStates.InteractWithBall.SubStates
{
    public class ClearBall : BState
    {
    }
}
