using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Finish : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject data;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Player")
        {
            data.GetComponent<Data>().speculationScore += 1;
            UIManager._instance.AddForceNumByint(1);
            SceneManager.LoadScene("Main---BJTU");

        }
    }
}
