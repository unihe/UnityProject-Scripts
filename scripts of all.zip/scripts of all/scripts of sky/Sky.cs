using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sky : MonoBehaviour
{
    public float DayLengthInMinutes;
    public float SkyRadius = 4000;
    public float HourOfDay;
    public Transform MidPoint;
    public Transform Sun;

    private float m_sunAngle;
    public float sunAngle
    {
        get
        {
            return m_sunAngle;
        }
        set
        {
            m_sunAngle = value;
            HourClamp();
        }

    }

    // Start is called before the first frame update
    void Start()
    {
        HourOfDay = 6;
    }
    void HourClamp()
    {
        if (HourOfDay <= 0)
        {
            HourOfDay = 0;
        }
        if (HourOfDay >= 24)
        {
            HourOfDay = 0;
        }
    }
    // Update is called once per frame
    void Update()
    {
        float oneDay = DayLengthInMinutes * 60;
        float oneHour = oneDay / 24;
        HourOfDay += Time.deltaTime / oneHour;
        float sunAngle = ((HourOfDay / 6) * 90) - 90;//-90
        Sun.transform.position = Quaternion.Euler(0, 0, sunAngle) * (SkyRadius * Vector3.right);//vector3:shorthand for (1,0,0)
        Sun.transform.LookAt(MidPoint);
    }
}

