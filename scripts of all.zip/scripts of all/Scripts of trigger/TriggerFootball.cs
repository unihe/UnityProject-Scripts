using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerFootball : MonoBehaviour
{
    private void OnTriggerStay(Collider other)
    {
        Character.instance.tFootball = true;
    }

    private void OnTriggerExit(Collider other)
    {
        Character.instance.tFootball = false;
    }
    

   
}
