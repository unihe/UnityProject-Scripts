using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerFruit : MonoBehaviour
{

    void OnTriggerStay(Collider other)
    {
        Character.instance.tClassroom = true;
    }

    void OnTriggerExit(Collider other)
    {
        Character.instance.tClassroom = false;
    }
}