using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TriggerBJTU : MonoBehaviour
{
    public GameObject data;
    private void OnTriggerStay(Collider other)
    {
        UIManager._instance.AddForceNumByint(1);
        data.GetComponent<Data>().speculationScore += 1;
        SceneManager.LoadScene("Main---BJTU");
    }
   
}
