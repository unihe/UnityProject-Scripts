using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerDoor : MonoBehaviour
{
    private void OnTriggerStay(Collider other)
    {
        Character.instance.tDoor = true;
    }

    private void OnTriggerExit(Collider other)
    {
        Character.instance.tDoor = false;
    }
    

   
}
