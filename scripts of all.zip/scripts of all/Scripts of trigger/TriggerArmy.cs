using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerArmy : MonoBehaviour
{
    private void OnTriggerStay(Collider other)
    {
        Character.instance.tArmy = true;
    }

    private void OnTriggerExit(Collider other)
    {
        Character.instance.tArmy = false;
    }
    

   
}
