using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerRace : MonoBehaviour
{
    private void OnTriggerStay(Collider other)
    {
        Character.instance.tRace = true;
    }

    private void OnTriggerExit(Collider other)
    {
        Character.instance.tRace = false;
    }
    

   
}
