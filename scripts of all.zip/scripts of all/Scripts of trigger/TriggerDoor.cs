using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerCar : MonoBehaviour
{
    private void OnTriggerStay(Collider other)
    {
        Character.instance.tCar = true;
    }

    private void OnTriggerExit(Collider other)
    {
        Character.instance.tCar = false;
    }
    

   
}
