using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerBuilding : MonoBehaviour
{
    private void OnTriggerStay(Collider other)
    {
        Character.instance.tBuilding = true;
    }

    private void OnTriggerExit(Collider other)
    {
        Character.instance.tBuilding = false;
    }
    

   
}
